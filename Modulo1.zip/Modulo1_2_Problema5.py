import pandas as pd
import numpy as np
import math

def salesMean():
    filename_comma = 'sales.csv'
    df_salesComma = pd.read_table(filename_comma, sep = ',', index_col = 'month')

    df_salesComma = df_salesComma.dropna(how = 'any')
    df_salesComma = np.array(df_salesComma)

    means = [0];
    for i in range(0,df_salesComma.shape[0]):
        means = np.vstack((means,df_salesComma[i,:].mean()))

    means = np.delete(means,(0), axis = 0)
    return means

print(salesMean())







import numpy as np

def IMC():
    height = np.round(np.random.normal(1.75, 0.20, 50),2)
    weight = np.round(np.random.normal(60.32, 15, 50), 2)

    data = np.column_stack((height, weight))

    list = [0]
    IMC = np.array(list)
    for i in range(0,len(data)):
        IMC1 = data[i,1]/(data[i,0] ** 2)
        IMC = np.row_stack((IMC,IMC1))

    #Since we initialized our list with a 0, we want to delete it
    IMC = np.delete(IMC, (0), axis=0)
    return IMC

print(IMC())


import numpy as np

def stats(list):

    list = np.array(list)

    media = np.mean(list)
    mediana = np.median(list)
    desvio = np.std(list)

    # return(desvio)

    finalList = [media , mediana , desvio]
    return finalList

print(stats([1,2,3]))

import pandas as pd


def hillary():
    df_elections = pd.read_csv('elections.csv',sep=',')
    candidates = df_elections['candidate']

    count=0
    for i in candidates:
        if(i == "Hillary Clinton"):
            count = count +1

    return count

print(hillary())
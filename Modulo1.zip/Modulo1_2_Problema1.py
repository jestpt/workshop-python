
def sumList(list1 , list2):

    newList=[0,0,0]

    #newList=[]
    for i in range(0,len(list1)):
        newList[i]=list1[i]+list2[i]

        #newList.append(list1[i]+list2[i])

    return newList

print(sumList([1,2,3],[1,1,1]))
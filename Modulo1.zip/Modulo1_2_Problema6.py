import numpy as np
import pandas as pd

def titanicData():
    data = pd.read_csv('titanic.rtf',sep=',')

    ageAverage = np.mean(data['Age'])
    malesinfo = data[data.Sex == 'male']
    femaleInfo = data[data.Sex == 'female']

    # Since the survived data is only 1's and 0's, if we sum the vector,
    # the final value will be the number of people who survived.
    survivedMales = sum(malesinfo.Survived)/len(malesinfo.Survived)
    survivedFemales = sum(femaleInfo.Survived)/len(femaleInfo.Survived)

    list = [ageAverage , survivedMales, survivedFemales]

    return list

info = titanicData()
print('Age average: ',info[0],'\nPercentage of males that survived: ',info[1]*100,'%','\nPercentage of males that survived: ',info[2]*100,'%')
